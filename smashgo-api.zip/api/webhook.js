export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).send('Method not allowed');
  }

  console.log("Webhook Asaas recebido:", req.body);

  return res.status(200).send("OK");
}
